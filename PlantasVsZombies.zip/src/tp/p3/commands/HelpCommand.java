package tp.p3.commands;

import tp.p3.logic.Game;

//Comando Help que muestra la informaci�n de los comandos, hereda de NoParamsCommand.
public class HelpCommand extends NoParamsCommand {

	//Constructor
	public HelpCommand() {
		super("help","[H]elp","print this help message.", "h");
	}

	@Override
	public boolean execute(Game game) {
		System.out.println(CommandParser.commandHelp());
		return false;	
	}
}
