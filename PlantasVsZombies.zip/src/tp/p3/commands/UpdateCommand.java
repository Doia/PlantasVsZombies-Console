package tp.p3.commands;

import tp.p3.logic.Game;

//Comando Update(none) que deja pasar un ciclo, hereda de NoParamsCommand.
public class UpdateCommand extends NoParamsCommand {

	//Contructor
	public UpdateCommand() {
		super("none","none","skips cycle.", "");
	}

	@Override
	public boolean execute(Game game) {
		return true;
	}
}