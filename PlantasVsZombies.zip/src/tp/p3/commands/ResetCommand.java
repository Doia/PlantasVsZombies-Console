package tp.p3.commands;

import tp.p3.logic.Game;

//Comando Reset para resetear el juego, hereda de NoParamsCommand.
public class ResetCommand extends NoParamsCommand {

	public ResetCommand() {
		super("reset","[R]eset"," resets game.", "r");
	}

	@Override
	public boolean execute(Game game) {
		game.resetGame();
		System.out.println(game.draw());
		return false;
	}
}
