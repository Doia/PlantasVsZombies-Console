package tp.p3.commands;

import tp.p3.Exceptions.CommandExecuteException;
import tp.p3.Exceptions.CommandParseException;
import tp.p3.Exceptions.InvalidPositionException;
import tp.p3.Exceptions.NoEmptyException;
import tp.p3.Exceptions.NoSuncoinException;
import tp.p3.Exceptions.PlantNameException;
import tp.p3.logic.Game;
import tp.p3.logic.PlantFactory;
import tp.p3.logic.objects.Plants;

//Comando Add para a�adir plantas, hereda de Command.
public class AddCommand extends Command {

	//Atributos
	private String plantName;
	private int x;
	private int y;
	
	//Constructor
	public AddCommand() {
		super("add","[A]dd <plant> <x> <y>"," adds a plant in position x, y.", "a");
	}

	@Override
	public boolean execute(Game game) throws CommandExecuteException {
		try {	
			Plants plant = PlantFactory.getPlant(this.plantName);
			game.addPlantToGame(plant, this.x, this.y);
		}
		catch (NoSuncoinException | PlantNameException | NoEmptyException |InvalidPositionException ex) {
			throw new CommandExecuteException(ex.getMessage());
		}
		return true;
	}

	@Override
	public Command parse(String[] commandWords) throws NumberFormatException, CommandParseException  {
		Command com = null;
		
		if ((commandWords[0].equals(commandName) || commandWords[0].equals(c))) {
			if(commandWords.length != 4) {
				throw new CommandParseException("Incorrect number of arguments for add command: " + this.commandText);
			}
			try {
				this.plantName = commandWords[1];
				this.x = Integer.parseInt(commandWords[2]);
				this.y = Integer.parseInt(commandWords[3]);
				com = this;
			}
			catch (NumberFormatException ex) {
				throw new CommandParseException("Invalid argument for add command, number expected: " + this.commandText);
			}
		}
		return com;
	}
}
