package tp.p3.commands;

import tp.p3.Exceptions.CommandExecuteException;
import tp.p3.Exceptions.CommandParseException;
import tp.p3.logic.Game;
import tp.p3.printer.DebugPrinter;
import tp.p3.printer.ReleasePrinter;

//Comando PrintMode que cambia la forma en la que se muestra el tablero, hereda de Command.
public class PrintModeCommand extends Command {

	//Atributos
	private String mode;
	
	//Constructor
	public PrintModeCommand() {
		super("printMode", "[P]rintMode", "change print mode [Release|Debug].", "p");
	}

	public boolean execute(Game game) throws CommandExecuteException {
		
		if(this.mode.equals("release")) {
			 game.setPrinter(new ReleasePrinter(Game.FILAS, Game.COLUMNAS));
		}
		else if(this.mode.equals("debug")) {
			game.setPrinter(new DebugPrinter(game.numPlants() + game.numZombies()));
		}
		else {
			throw new CommandExecuteException("Unknown print mode: " + this.mode);
		}
		return true;
	}
	
	@Override
	public Command parse(String[] commandWords) throws CommandParseException {
		Command com = null;
		if ((commandWords[0].equals(commandName) || commandWords[0].equals(c))) {
			
			if(commandWords.length != 2) {
				throw new CommandParseException("Incorrect number of arguments for printMode command: [P]rintMode Release|Debug");
			}
			this.mode = commandWords[1];
			com = this;
		}
		return com;
	}
}
