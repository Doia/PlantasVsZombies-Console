package tp.p3.commands;

import tp.p3.logic.Game;
import tp.p3.logic.PlantFactory;

//Comando List que muestra la lista de plantas y su informaci�n, hereda de NoParamsCommand.
public class ListCommand extends NoParamsCommand {
	
	//Constructor
	public ListCommand() {
		super("list","[L]ist","print the list of available plants.", "l");
	}

	@Override
	public boolean execute(Game game) {
		System.out.println(PlantFactory.listOfAvilablePlants());
		return false;
	}
}
