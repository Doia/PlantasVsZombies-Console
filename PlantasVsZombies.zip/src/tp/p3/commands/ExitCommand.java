package tp.p3.commands;

import tp.p3.logic.Game;

//Comando Exit para salir de la partida, hereda de NoParamsCommand.
public class ExitCommand extends NoParamsCommand {

	//Constructor
	public ExitCommand() {
		super("exit","[E]xit"," terminate the program.", "e");
	}

	@Override
	public boolean execute(Game game) {
		game.setExit(true);
		System.out.println();
		System.out.println("****** Game over! : User exit ******");
		return false;
	}
}
