package tp.p3.commands;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import tp.p3.Exceptions.CommandExecuteException;
import tp.p3.Exceptions.CommandParseException;
import tp.p3.logic.Game;
import tp.p3.util.MyStringUtils;

//Comando Save para guardar una partida, hereda de Command.
public class SaveCommand extends Command {

	//Atributos
	private String fileName;
	public static final String header = "Plants Vs Zombies v3.0";
	
	//Constructor
	public SaveCommand() {
		super("save", "[S]ave <filename>", " Save the state of the game to a file.", "s");
	}

	@Override
	public boolean execute(Game game) throws CommandExecuteException{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
			bw.write(header);
			bw.newLine();
			bw.newLine();
			game.save(bw);
			System.out.println("Game successfully saved to file "+ this.fileName +"; use the load command to reload it.\n");
		}
		catch (IOException ex) {
			throw new CommandExecuteException(ex.getMessage());
		}
		return false;
	}

	@Override
	public Command parse(String[] commandWords) throws CommandParseException {
		Command com = null;
		
		if ((commandWords[0].equals(commandName) || commandWords[0].equals(c))) {
			
			if(commandWords.length != 2) {
				throw new CommandParseException("Incorrect number of arguments for add command: " + this.commandText);
			}
			if(!MyStringUtils.isValidFilename(commandWords[1])) {
				throw new CommandParseException("Invalid filename: the filename contains invalid characters.");
			}
			this.fileName = commandWords[1];
			com = this;
		}
		return com;
	}
}
