package tp.p3.commands;

import tp.p3.Exceptions.CommandParseException;

//Clase est�tica que crea y parsea los comandos.
public class CommandParser {

	//Atributos
	private static Command[] availableCommands = {
			new AddCommand(),
			new HelpCommand(),
			new ResetCommand(),
			new ExitCommand(),
			new ListCommand(),
			new ListZombiesCommand(),
			new UpdateCommand(),
			new PrintModeCommand(),
			new SaveCommand(),
			new LoadCommand(),
	};
	
	public static Command parseCommand(String[] words) throws CommandParseException {
		Command command = null;
		
		int i = 0;
		while ((i < availableCommands.length) && (command == null)) {
			command = availableCommands[i].parse(words);
			++i;
		}
		if (command == null) {
			throw new CommandParseException("Unknown command. Use �help� to see the available commands");
		}
		return command;
	}
	
	public static String commandHelp() {
		StringBuilder cHelp = new StringBuilder();
		
		for (int i = 0; i < availableCommands.length; i++) {
			cHelp.append(availableCommands[i].helpText()).append("\n");
		}
		return cHelp.toString();	
	}
}
