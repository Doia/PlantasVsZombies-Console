package tp.p3.commands;

import tp.p3.logic.Game;
import tp.p3.logic.ZombieFactory;

public class ListZombiesCommand extends NoParamsCommand {
	//Constructor
		public ListZombiesCommand() {
			super("listzombies","[L]ist[Z]ombies","print the list of available zombies.", "lz");
		}

		@Override
		public boolean execute(Game game) {
			System.out.println(ZombieFactory.listOfAvilableZombies());
			return false;
		}
}
