package tp.p3.commands;

import tp.p3.Exceptions.CommandExecuteException;
import tp.p3.Exceptions.CommandParseException;
import tp.p3.logic.Game;

//Clase abstracta de la que heredan todos los comandos.
public abstract class Command {
	
	//Atributos
	protected String c;
	private String helpText;
	protected String commandText;
	protected final String commandName;
	
	//Constructor
	public Command(String commandText, String commandInfo, String helpInfo, String c){
		this.commandText = commandInfo;
		helpText = helpInfo;
		String[] commandInfoWords = commandText.split("\\s+");
		commandName = commandInfoWords[0];
		this.c = c;
	}
	
	public abstract boolean execute(Game game) throws CommandExecuteException;
	public abstract Command parse(String[] commandWords) throws NumberFormatException, CommandParseException;
	
	public String helpText(){
		return " " + commandText + ": " + helpText;
	}
}
