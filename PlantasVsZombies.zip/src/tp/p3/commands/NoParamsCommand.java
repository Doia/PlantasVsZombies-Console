package tp.p3.commands;

import tp.p3.Exceptions.CommandParseException;
import tp.p3.logic.Game;

//Clase intermedia para los comandos sin par�metros, hereda de Command.
public class NoParamsCommand extends Command {

	//Constructor
	public NoParamsCommand(String commandText, String commandInfo, String helpInfo, String c) {
		super(commandText, commandInfo, helpInfo, c);
	}

	@Override
	public boolean execute(Game game) {
		return false;
	}

	@Override
	public Command parse(String[] commandWords) throws CommandParseException {
		Command com = null;
		if((commandWords[0].equals(commandName) || commandWords[0].equals(c) ) ) {
			if(commandWords.length != 1) {
				throw new CommandParseException(commandWords[0]  + " command has no arguments");
			}
			com = this;
		}
		return com;
	}
}