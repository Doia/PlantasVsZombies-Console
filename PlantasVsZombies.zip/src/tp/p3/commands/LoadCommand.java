package tp.p3.commands;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import tp.p3.Exceptions.CommandExecuteException;
import tp.p3.Exceptions.CommandParseException;
import tp.p3.logic.Game;
import tp.p3.util.MyStringUtils;

//Comando Load para cargar una partida, hereda de Command
public class LoadCommand extends Command {
	
	//Atributos
	private String fileName;
	public static final String header = "Plants Vs Zombies v3.0";
	
	//Constructor
	public LoadCommand() {
		super("load", "[Lo]ad <filename>", "Load the state of the game from a file.", "lo");
	}

	@Override
	public boolean execute(Game game) throws CommandExecuteException {
		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			String s = br.readLine();
			if(!s.equals(header)) {
				throw new CommandExecuteException("Load failed: invalid file contents.");
			}
			br.readLine();
			game.load(br);
			
			System.out.println("Game successfully loaded from file " + this.fileName + '\n');
			System.out.println(game.draw());
		}
		catch (IOException ex) {
			throw new CommandExecuteException(ex.getMessage());
		}
		return false;
	}

	@Override
	public Command parse(String[] commandWords) throws NumberFormatException, CommandParseException {
		Command com = null;
		
		if ((commandWords[0].equals(commandName) || commandWords[0].equals(c))) {
			
			if(commandWords.length != 2) {
				throw new CommandParseException("Incorrect number of arguments for add command: " + this.commandText);
			}
			if(!MyStringUtils.isValidFilename(commandWords[1])) {
				throw new CommandParseException("Invalid filename: the filename contains invalid characters.");
			}
			if(!MyStringUtils.fileExists(commandWords[1])) {
				throw new CommandParseException("File not found.");
			}
			if(!MyStringUtils.isReadable(commandWords[1])) {
				throw new CommandParseException("You don't have permissions.");
			}
			
			this.fileName = commandWords[1];
			com = this;
		}
		return com;
	}
}
