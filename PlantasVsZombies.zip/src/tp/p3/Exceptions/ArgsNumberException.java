package tp.p3.Exceptions;

//Excepci�n para controlar el n�mero de par�metros al ejecutar el juego.
@SuppressWarnings("serial")
public class ArgsNumberException extends Exception {
	
	public ArgsNumberException(String msg) {
		super(msg);
	}
}
