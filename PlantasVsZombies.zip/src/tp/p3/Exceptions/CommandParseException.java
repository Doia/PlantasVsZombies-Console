package tp.p3.Exceptions;

//Excepci�n que controla las excepciones del tipo command-parse.
@SuppressWarnings("serial")
public class CommandParseException extends Exception {
	
	public CommandParseException (String msg) {
		super(msg);
	}
}
