package tp.p3.Exceptions;

//Excepci�n que controla las excepciones del tipo command-execute.
@SuppressWarnings("serial")
public class CommandExecuteException extends Exception {

	public CommandExecuteException(String msg) {
		super(msg);
	}
}
