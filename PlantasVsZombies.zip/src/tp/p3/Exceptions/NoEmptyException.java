package tp.p3.Exceptions;

//Excepci�n que controla si una posici�n ya est� ocupada.
@SuppressWarnings("serial")
public class NoEmptyException extends Exception {
	
	public NoEmptyException(String msg) {
		super(msg);
	}
}
