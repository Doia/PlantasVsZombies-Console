package tp.p3.Exceptions;

//Excepci�n que controla si el nivel es incorrecto.
@SuppressWarnings("serial")
public class LevelException extends Exception {

	public LevelException(String msg) {
		super(msg);
	}
}
