package tp.p3.Exceptions;

//Excepci�n que controla si la planta que se desea a�adir es correcta.
@SuppressWarnings("serial")
public class PlantNameException extends Exception {

	public PlantNameException(String msg) {
		super(msg);
	}
}
