package tp.p3.Exceptions;

//Excepci�n que controla si la semilla introducida es correcta.
@SuppressWarnings("serial")
public class seedException extends Exception {

	public seedException(String msg) {
		super(msg);
	}
}
