package tp.p3.Exceptions;

//Excepci�n para controlar si una posici�n no es correcta.
@SuppressWarnings("serial")
public class InvalidPositionException extends Exception {
	
	public InvalidPositionException(String msg) {
		super(msg);
	}
}
