package tp.p3.Exceptions;

//Excepci�n para controlar si el contenido de un fichero es inv�lido.
@SuppressWarnings("serial")
public class FileContentsException extends Exception {

	public FileContentsException(String msg) {
		super(msg);	
	}
}
