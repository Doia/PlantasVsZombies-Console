package tp.p3.Exceptions;

//Excepci�n que controla si no hay suficientes sunsCoins para comprar una planta.
@SuppressWarnings("serial")
public class NoSuncoinException extends Exception {

	public NoSuncoinException(String msg) {
		super(msg);
	}
}
