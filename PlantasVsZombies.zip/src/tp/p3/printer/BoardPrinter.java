package tp.p3.printer;

import tp.p3.logic.Game;
import tp.p3.util.MyStringUtils;

//Clase abstracta madre de los dos modos de pintado. Implementa GamePrinterI
public abstract class BoardPrinter  implements GamePrinterI{
	
	//Atributos
	final String space = " ";
	protected int dimX; 
	protected int dimY;
	protected String[][] board;
	protected int cellSize;
	
	//Constructor
	public BoardPrinter(int dimX, int dimY, int cellS) {
		this.dimX = dimX;
		this.dimY = dimY;
		this.cellSize = cellS;
	}
	
	public abstract void encodeGame(Game game);  
	public abstract String printGame(Game game);
	
	public String toString() {
		int marginSize = 2;
		String vDelimiter = "|";
		String hDelimiter = "-";
		
		String rowDelimiter = MyStringUtils.repeat(hDelimiter, (dimY * (this.cellSize + 1)) - 1);
		String margin = MyStringUtils.repeat(space, marginSize);
		String lineDelimiter = String.format("%n%s%s%n", margin + space, rowDelimiter);
		
		StringBuilder str = new StringBuilder();
		
		str.append(lineDelimiter);
		
		for(int i=0; i<dimX; i++) {
				str.append(margin).append(vDelimiter);
				for (int j=0; j<dimY; j++) {
					str.append( MyStringUtils.centre(board[i][j], this.cellSize)).append(vDelimiter);
				}
				str.append(lineDelimiter);
		}
		return str.toString();
	}
}
