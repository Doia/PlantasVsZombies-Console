package tp.p3.printer;

import tp.p3.logic.Game;

//Clase para mostrar el tablero en modo Debug, hereda de BoardPrinter.
public class DebugPrinter extends BoardPrinter {
	
	public final static int cellSize = 19;
	
	//Contructor
	public DebugPrinter(int n) {
		super(1, n, cellSize);
	}
	
	@Override
	public void encodeGame(Game game) {
		String str = "EMPTY";
		dimY  = game.numPlants() + game.numZombies();
		if (dimY == 0) {
			dimY = 1;
		}
		board = new String[dimX][dimY];
		int k = 0;
		
		board [0][k] = str;
		
		for(int i = 0; i < game.numPlants() ; i++) {			
			str = game.searchObjectDebug(i,true);
			board[0][k] = str;
			k++;
		}
		for(int i = 0; i < game.numZombies() ; i++) {			
			str = game.searchObjectDebug(i,false);	
			board[0][k] = str;
			k++;
		}
	}

	@Override
	public String printGame(Game game) {
		encodeGame(game);
		return game.infoWin() + game.infoDebug() +  toString();
	}
}
