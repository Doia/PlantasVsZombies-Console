package tp.p3.printer;

import tp.p3.logic.Game;

//Interfaz 
public interface GamePrinterI {
	
	public String printGame(Game game);
	
}
