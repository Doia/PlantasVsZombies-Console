package tp.p3.printer;

import tp.p3.logic.Game;

//Clase para mostrar el tablero en modo Release, hereda de BoardPrinter.
public class ReleasePrinter extends BoardPrinter  {
	
	public final static int cellSize = 7;
	 
	//Contructor
	public  ReleasePrinter(int dimX, int dimY) {
		super(dimX, dimY, cellSize);	
	}
	
	@Override
	public void encodeGame(Game game) {
		board = new String[dimX][dimY];
		for(int i = 0; i < dimX; i++) {
			for(int j = 0; j < dimY; j++) {
				
				board[i][j] = game.searchObjectRelease(i, j);
				
				if(board[i][j] == null) {
					board[i][j] =  space;
				}
			}
		}
	}
	
	@Override
	public String printGame(Game game) {
		encodeGame(game);
		return game.infoWin() + game.infoRelease() +  toString();	
	}
}
