package tp.p3.logic;

//Lleva el control de los suncoins.
public class SuncoinManager {

	//Atributos
	private int suns;
	
	//Constructor
	public SuncoinManager() {
		this.suns = 50;
	}
	
	//Getters
	public int getSuns() {
		return this.suns;
	}
	
	//Setters
	public void setSuns(int suns) {
		this.suns = suns;
	}
	
	public void pay(int cost) {
		this.suns -= cost;
	}
	
	public void collectSuns(int sun) {
		this.suns += sun;
	}
}
