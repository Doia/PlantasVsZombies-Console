package tp.p3.logic.objects;

public class Wallnut extends Plants {
	
	public static final int lifeConst = 8;
	public static final int frequencyConst = 1;
	public static final int freqCountConst = 0;
	public static final int costConst = 50;
	public static final String plantNameConst = "[W]allnut";
	public static final String initialConst = "W";
	public static final String name = "wallnut";
	
	//Constructor
	public Wallnut() {
		super(lifeConst, frequencyConst, costConst, plantNameConst, initialConst, freqCountConst, name);
	}

	@Override
	public void update() {}
	
	public Wallnut cloneMe() {
		return new Wallnut();
	}
	
	public String plantText() {
		return super.plantText() + "Harm: " + 0;  
	}
}