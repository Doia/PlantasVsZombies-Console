package tp.p3.logic.objects;

public abstract class Zombies extends GameObject {
	
	//Atributos
	protected int frequency;
	protected int harm;
	
	//Constructores
	public Zombies(int freqCountConst, String initialConst, int lifeConst, int frequencyConst, int harmConst, String zombieNameConst, String name) {
		super(lifeConst, initialConst,freqCountConst, zombieNameConst, name);
		this.frequency = frequencyConst;
		this.harm = harmConst;
	}
	
	public abstract void update();
	
	public void objectAction() {
			if (game.repasarListas(this.x, this.y - 1)&&(this.freqCount == 0)) {
				this.y = this.y - 1;
			}
			else if ( !game.existZombie(this.x, this.y - 1) ) {
				game.zombieAttack(x, y-1, this.harm);
			}
			if(this.freqCount == 0) {
				this.freqCount = this.frequency - 1;
			}
			else {
				this.freqCount--;
		}
	}
	
	public String zombieText() {
		return " " + objectName + ": Harm: " + this.harm + " Frequency: " + this.frequency; 
	}
}
