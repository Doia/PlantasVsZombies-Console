package tp.p3.logic.objects;

//Objeto sunflower: Genera soles.
public class Sunflower extends Plants {
	
	//Atributos
	private int increaseSol;
	public static final int lifeConst = 1;
	public static final int frequencyConst = 2;
	public static final int freqCountConst = 1;
	public static final int costConst = 20;
	public static final String plantNameConst = "[S]unflower";
	public static final String initialConst = "S";
	public static final String name = "sunflower";
	
	//Constructor
	public Sunflower() {
		super(lifeConst, frequencyConst, costConst, plantNameConst, initialConst, freqCountConst, name); 
		this.increaseSol = 10;
	}

	//Devuelve el n�mero de soles que tiene que aumentar en el ciclo.
	public int sol() {
		int sol = 0;
		
		if(this.freqCount == 0) {
			sol = this.increaseSol;
			this.freqCount = this.frequency - 1;
		}
		else {
			this.freqCount--;
			sol = 0;	
		}
		return sol;
	}
	
	//Acci�n: Aumentar los soles.
	public void update() {
		game.sunGenerator(sol());
	}
	
	public Sunflower cloneMe() {
		return new Sunflower();
	}
	
	public String plantText() {
		return super.plantText() + "Harm: " + 0;  
	}
}
