package tp.p3.logic.objects;

public class NormalZombie extends Zombies {

	//Atributos
	public static final int lifeConst = 5;
	public static final int frequencyConst = 2;
	public static final int freqCountConst = 1;
	public static final int harmConst = 1;
	public static final String initialConst = "Z";
	public static final String zombieName = "Normal[Z]ombie";
	public static final String name = "normal";
	
	//Constructores
	public NormalZombie() {
		super(freqCountConst, initialConst, lifeConst, frequencyConst, harmConst, zombieName, name);
	}
	
	public NormalZombie cloneMe() {
		return new NormalZombie();
	}
	
	@Override
	public void update() {
		objectAction();
	}
}
