package tp.p3.logic.objects;

public class CherryBomb extends Plants {

	//Atributos
	private int harm;
	public static final int lifeConst = 2;
	public static final int frequencyConst = 2;
	public static final int freqCountConst = 1;
	public static final int costConst = 50;
	public static final String plantNameConst = "[C]herryBomb";
	public static final String initialConst = "C";
	public static final String name = "cherrybomb";
	
	//Constructore
	public CherryBomb() {
		super(lifeConst, frequencyConst, costConst, plantNameConst, initialConst, freqCountConst, name);
		this.harm = 10;
	}

	@Override
	public void update() {
		if(this.freqCount == 0) {
			game.plantExplote(this.x, this.y, harm);
			this.life = 0;
		}
		else {
			this.freqCount--;
		}
	}
	
	public CherryBomb cloneMe() {
		return new CherryBomb();
	}
	
	public String plantText() {
		return super.plantText() + "Harm: " + harm;  
	}
}
