package tp.p3.logic.objects;

import tp.p3.logic.Game;

//Clase (abstracta) madre de los objetos: plantas y zombies.
public abstract class GameObject {
	
	//Atributos
	protected int x;
	protected int y;
	protected int life;
	protected int freqCount;
	protected String initial;
	protected Game game;
	protected String objectName;
	protected String name;
	
	//Constructores
	public GameObject(int lifeConst, String initialConst , int freqCountConst, String objectNameConst, String name){
		this.x = 0;
		this.y = 0;
		this.freqCount = freqCountConst;
		this.life = lifeConst;
		this.initial = initialConst;
		this.objectName = objectNameConst;
		this.name = name;
	}

	//Setters
	public void setGame(Game game) {
		this.game = game;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public void setLife(int life) {
		this.life = life;
	}
	
	public void setInitial(String initial) {
		this.initial = initial;
	}
	
	public void setFreqCount(int fCount) {
		this.freqCount = fCount;
	}
	
	//Getters
	public String getName() {
		return this.name;
	}
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
	
	public void losesLife(int harm) {
		this.life -= harm;
	}
	
	public boolean isAlive() {
		return (this.life > 0);
		
	}
	
	public GameObject parse(String name) {
		GameObject o = null;
		if((name.equals(this.name)) || (name.equals(this.initial.toLowerCase()))){
			o = cloneMe();
		}
		return o;
	}
	 
	public abstract GameObject cloneMe();
	 
	public String toStringRelease() {
		return (this.initial + " ["+ this.life +"]");
	}
	
	public String toStringDebug() {
		return (this.initial + " [L:"+ this.life +",X:" + this.x + ",Y:" + this.y + ",T:" + this.freqCount + "]");
	}
	
	public String toStringSave() {
		return (this.initial + ":" + this.life + ":" + this.x + ":" + this.y + ":" + this.freqCount);
	}
	
	public abstract void update();
}
