package tp.p3.logic.objects;

public class ZombieRunner extends Zombies {

	//Atributos
	public static final int lifeConst = 2;
	public static final int frequencyConst = 1;
	public static final int freqCountConst = 0;
	public static final int harmConst = 1;
	public static final String initialConst = "R";
	public static final String zombieName = "Zombie[R]unner";
	public static final String name = "runner";
	
	//Constructores
	public ZombieRunner() {
		super(freqCountConst, initialConst, lifeConst, frequencyConst, harmConst, zombieName, name);
	}
	
	public ZombieRunner cloneMe() {
		return new ZombieRunner();
	}
	
	@Override
	public void update() {
		objectAction();
	}
}