package tp.p3.logic.objects;

//Objeto Peashooter: Dispara guisantes a los zombies caus�ndoles da�o.
public class Peashooter extends Plants{
	
	//Atributos
	private int harm;
	public static final int lifeConst = 5;
	public static final int frequencyConst = 1;
	public static final int freqCountConst = 0;
	public static final int costConst = 50;
	public static final String plantNameConst = "[P]eashooter";
	public static final String initialConst = "P";
	public static final String name = "peashooter";
	
	//Constructor
	public Peashooter() {
		super(lifeConst, frequencyConst, costConst, plantNameConst, initialConst, freqCountConst, name);
		this.harm = 1;
	}
	
	//Acci�n: Dispara al primer zombie que tenga delante quit�ndole vida.
	public void update() {
		
		if(this.freqCount == 0) {
			game.plantShoot(this.x, this.y, this.harm);
			this.freqCount = this.frequency -1 ;
		}
		else {
			this.freqCount--;
		}	
	}
	
	public Peashooter cloneMe() {
		return new Peashooter();
	}
	
	public String plantText() {
		return super.plantText() + "Harm: " + harm;  
	}
}
