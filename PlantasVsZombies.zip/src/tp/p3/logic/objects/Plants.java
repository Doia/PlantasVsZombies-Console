package tp.p3.logic.objects;

public abstract class Plants extends GameObject {
	
	//Atributos
	protected int frequency;
	protected int cost;
	
	//Constructores
	public Plants(int lifeConst, int frequencyConst, int costConst, String plantNameConst, String initialConst, int freqCountConst, String name){
		super(lifeConst, initialConst, freqCountConst, plantNameConst, name);
		this.cost = costConst;
		this.frequency = frequencyConst;
	}
	
	//Getters
	public int getCost() {
		return this.cost;
	}
	
	public int getFrequency() {
		return this.frequency;
	}

	public String getPlantName() {
		return this.objectName;
	}
	//Setters
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	public String plantText() {
		return " " + objectName + ": Cost: " + cost + " sunscoins ";  
	}
}
