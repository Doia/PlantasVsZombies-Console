package tp.p3.logic.objects;

public class BucketHead extends Zombies {
	
	//Atributos
	public static final int lifeConst = 8;
	public static final int frequencyConst = 4;
	public static final int freqCountConst = 3;
	public static final int harmConst = 1;
	public static final String zombieNameConst = "[B]ucketHead";
	public static final String initialConst = "B";
	public static final String name = "bucket";
	
	//Constructores
	public BucketHead() {
		super( freqCountConst, initialConst, lifeConst, frequencyConst, harmConst, zombieNameConst, name);
	}
	
	public BucketHead cloneMe() {
		return new BucketHead();
	}
	@Override
	public void update() {
		objectAction();
	}
}
