package tp.p3.logic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Random;

import tp.p3.Exceptions.CommandExecuteException;
import tp.p3.Exceptions.FileContentsException;
import tp.p3.Exceptions.InvalidPositionException;
import tp.p3.Exceptions.NoEmptyException;
import tp.p3.Exceptions.NoSuncoinException;
import tp.p3.logic.GameObjectList;
import tp.p3.logic.objects.GameObject;
import tp.p3.logic.objects.Plants;
import tp.p3.logic.objects.Zombies;
import tp.p3.printer.GamePrinterI;
import tp.p3.printer.ReleasePrinter;
import tp.p3.util.MyStringUtils;

//Encapsula la l�gica del juego.
public class Game {
	
	//Constantes
	public static final int NUMPLANTS = 50;
	public static final int FILAS = 4;
	public static final int COLUMNAS = 8;
	public static final String wrongPrefixMsg = "unknown game attribute: ";
	public static final String lineTooLongMsg = "too many words on line commencing: ";
	public static final String lineTooShortMsg = "missing data on line commencing: ";
	public static final String PlantPosErrMsg = "last column is restringed to plants.";
	public static final String invPosErrMsg = "is an invalid position";
	public static final String occupiedErrMsg = "is already occupied";
	public static final String  noSunsErrMsg = ": not enough suncoins to buy it";
	
	//Atributos
	private GameObjectList plantList;
	private GameObjectList zombieList;
	private SuncoinManager sManager;
	private ZombieManager zManager;
	private int turnCount;
	private Level level;
	private Random rand;
	private long seed;
	private boolean zombiesWin;
	private boolean plantsWin;
	private GamePrinterI printer;
	private boolean exit;
	
	//Constructor
	public Game(Level level, long seed) {
		this.turnCount = 0;
		this.plantList = new GameObjectList(NUMPLANTS);
		this.zombieList = new GameObjectList(level.getNumberOfZombies());
		this.sManager = new SuncoinManager();
		this.zManager = new ZombieManager(level) ;
		this.rand = new Random (seed);
		this.level = level;
		this.seed = seed;
		this.printer = new ReleasePrinter(FILAS, COLUMNAS);
		this.exit = false;
	}
	
	public String getLevel() {
		return level.name();
	}
	
	public int getContadorCiclos() {
		return this.turnCount;
	}
	
	public Random getSeed() {
		return this.rand;
	}
	
	public boolean getZombiesWin() {
		return this.zombiesWin;
	}
	
	public boolean getPlantsWin() {
		return this.plantsWin;
	}
		
	public GamePrinterI getPrinter() {
		return  this.printer;
	}
	
	public boolean getExit() {
		return this.exit;
	}
	
	//Setters
	public void setPrinter(GamePrinterI p) {
		this.printer =  p;
	}
	
	public void setExit(boolean exit) {
		this.exit = exit;
	}
	
	//Se actualiza el juego.
	public void update() {
		this.plantList.update();
		this.zombieList.killObject();
		this.zombieList.update();
		this.zombiesWin = this.zombiesWin();
		this.plantList.killObject();
		
		if (!this.zombiesWin) {
			this.plantsWin = ((zManager.getZombies() == 0) && (zombieList.getCont() == 0));
		}
	}
	
	public int numPlants() {
		return this.plantList.getCont();
	}
	
	public int numZombies() {
		return this.zombieList.getCont();
	}

	//Dibuja el juego.
	public String draw() {
		return printer.printGame(this);
	}
	
	//Comprueba en todas las listas si una posici�n est� vac�a.
	public boolean repasarListas(int x, int y) {
		boolean vacio = false;
		
		if (((0 <= x ) && (x < FILAS)) && ((0 <= y ) && (y < COLUMNAS))) {
			vacio = this.plantList.estaVacio(x, y);
			
			if (vacio) {
				vacio = this.zombieList.estaVacio(x, y);
			}
		}
		return vacio;
	}
	
	//Busca un objeto en las listas y devuelve su String para el modo Release.
	public String searchObjectRelease(int x, int y) {
		String str;
		
		String buscaP = this.plantList.searchObjectRelease(x, y); 
		String buscaZ = this.zombieList.searchObjectRelease(x, y);
		
		if(buscaP != null) {
			str = buscaP;
		}
		else if (buscaZ != null) {
			str = buscaZ;
		}
		else {
			str = null;
		}	
		return str;
	}
	
	//Busca un objeto en las listas y devuelve su String para el modo Debug.
	public String searchObjectDebug(int i, boolean isPlant) {
		String str;
		
		if (isPlant) {
			str = plantList.searchObjectDebug(i);
		}
		else {
			str = zombieList.searchObjectDebug(i);
		}
		return str;
	}
	
	//A�ade zombies de forma aleatoria.
	public void computerAction()  {
		Zombies z;
		String type = null;
		
		if (zManager.getZombies() > 0) {
			if(zManager.comesOutZombie(level, rand)) {
				type = zManager.chooseType(rand);
				int fila = this.rand.nextInt(FILAS);
				
				if (repasarListas(fila,COLUMNAS - 1)) {
					z = ZombieFactory.getZombie(type);
					setObject(z, fila, COLUMNAS -1);
					zombieList.addObject(z);
					zManager.setZombies(zManager.getZombies() - 1);
				}
				else {
					boolean free = false;
					
					int i = 0;	
					while ((i < FILAS) && !free) {
						free = repasarListas(i, COLUMNAS - 1);
						i++;
					}
					if(free) {
						z = ZombieFactory.getZombie(type);
						setObject(z, i-1, COLUMNAS -1);
						zombieList.addObject(z);
						zManager.setZombies(zManager.getZombies() - 1);
					}
				}
			}
		}
	}
	
	//Comprueba si hay un zombie en una posici�n
	public boolean existZombie(int x, int y) {
		boolean hayZombie = true;
		hayZombie = !this.zombieList.estaVacio(x, y);
		return hayZombie;
	}

	//Reset del juego.
	public void resetGame() {
		this.turnCount = 0;
		this.plantList = new GameObjectList(NUMPLANTS);
		this.zombieList = new GameObjectList(level.getNumberOfZombies());
		this.sManager = new SuncoinManager();
		this.zManager = new ZombieManager(level) ;
		this.rand = new Random (seed);
		this.printer = new ReleasePrinter(FILAS, COLUMNAS);
	}
	
	//El zombie provoca da�o a las plantas.
	public void zombieAttack(int x, int y, int harm) {
		plantList.takeDamageObject(x, y, harm);
	}
	
	//Un peashooter dispara a un zombie.
	public void plantShoot(int x, int y, int harm) {
		boolean takedDamage = false;
		while (y < COLUMNAS && !takedDamage) {
			takedDamage = zombieList.takeDamageObject(x, y, harm);
			++y;
		}
	}
	
	//Una CherryBomb hace explotar al los zombies a su alrededor.
	public void plantExplote(int x, int y, int harm) {
		zombieList.takeDamageObject(x - 1, y,  	  harm);
		zombieList.takeDamageObject(x + 1, y, 	  harm);
		zombieList.takeDamageObject(x,     y - 1, harm);
		zombieList.takeDamageObject(x,     y + 1, harm);
		zombieList.takeDamageObject(x + 1, y - 1, harm);
		zombieList.takeDamageObject(x - 1, y + 1, harm);
		zombieList.takeDamageObject(x + 1, y + 1, harm);
		zombieList.takeDamageObject(x -1,  y - 1, harm);
		zombieList.takeDamageObject(x, y, harm);
	}

	//Modifica los soles.
	public void sunGenerator(int sun) {
		sManager.collectSuns(sun);
	}
	
	//Muestra la informaci�n en el modo Release.
	public String infoRelease() {
		StringBuilder str = new StringBuilder();
		str.append("Number of cycles: ").append(this.turnCount);
		str.append("\nSun coins: ").append(this.sManager.getSuns());
		str.append("\nRemaining zombies: ").append(this.zManager.getZombies());
		return str.toString();
	}
	
	//Muestra la informaci�n en el modo Debug.
	public String infoDebug() {
		StringBuilder str = new StringBuilder();
		str.append("Number of cycles: ").append(this.turnCount);
		str.append("\nSun coins: ").append(this.sManager.getSuns());
		str.append("\nRemaining zombies: ").append(this.zManager.getZombies());
		str.append("\nLevel: ").append(this.getLevel());
		str.append("\nSeed: ").append(this.seed);
		return str.toString();
	}
	
	//Muestra un mensaje con el ganador del juego.
	public String infoWin() {
		String enter = "\n";
		String decor = MyStringUtils.repeat("*", 65);
		String infoWin = null;
		StringBuilder str = new StringBuilder();
		
		if (plantsWin || zombiesWin) {
			if (plantsWin) {
				infoWin = "YOU HAVE WON THE GAME! :)";
			}
			else {
				infoWin = "THE ZOMBIES HAVE EATEN YOUR BRAIN! :(";
			}
			str.append(enter + enter);
			str.append(decor);
			str.append(enter);
			str.append(MyStringUtils.centre(infoWin, 65));
			str.append(enter);
			str.append(decor);
			str.append(enter);
		}
		return str.toString();
	}
	
	//Comprueba si el juego ha acabado.
	public boolean isFinished() {
		return this.getPlantsWin() || this.getZombiesWin()|| this.exit;
	}
	
	//A�ade una planta.
	public void addPlantToGame(Plants plant, int x, int y) throws NoSuncoinException, NoEmptyException, InvalidPositionException {
	
			if (plant.getCost() <= sManager.getSuns()) {	
				if (repasarListas(x,y)) {
					if (y != COLUMNAS -1) {
						setObject(plant,x,y);
						plantList.addObject(plant);
						sManager.pay(plant.getCost());
					}
					else
						throw new InvalidPositionException("Failed to add " + plant.getPlantName() + ": (" + x + ", " + y + ") " + PlantPosErrMsg);
				}
				else {
					if (!(((0 <= x ) && (x < FILAS)) && ((0 <= y ) && (y < COLUMNAS)))){
						throw new InvalidPositionException("Failed to add " + plant.getPlantName() + ": (" + x + ", " + y + ") "+ invPosErrMsg);
					}
					else 
						throw new NoEmptyException("Failed to add " + plant.getPlantName() + ": position (" + x + ", " + y +") " + occupiedErrMsg);
				}
			}
			else 
				throw new NoSuncoinException("Failed to add " + plant.getPlantName() + noSunsErrMsg );
	}
	
	//Comprueba si han ganado los zombies.
	public boolean zombiesWin(){
		boolean zWin = false;
		int i = 0;
		while (i < FILAS && !zWin) {
			zWin = !this.zombieList.estaVacio(i, 0);
			i++;
		}
		return zWin;
	}
	
	//Pasa de ciclo.
	public void nextTurn() { 
		this.turnCount++;
	}
	
	//Guarda la partida.
	public void save(BufferedWriter bw) throws IOException {
		bw.write("cycle: " + this.turnCount);
		bw.newLine();
		bw.write("sunCoins:" + sManager.getSuns());
		bw.newLine();
		bw.write("level: " + this.level.name());
		bw.newLine();
		bw.write("remZombies: " + zManager.getZombies());
		bw.newLine();
		bw.write("plantList: " + plantList.save());
		bw.newLine();
		bw.write("zombieList: " + zombieList.save());
	}

	public String[] loadLine(BufferedReader inStream, String prefix, boolean isList) throws IOException, FileContentsException {
		String line = inStream.readLine().trim();
		if(!line.startsWith(prefix + ":"))
			throw new FileContentsException(wrongPrefixMsg + prefix);
		
		String contentString = line.substring(prefix.length() + 1).trim();
		String[] words;
		
		if(!contentString.equals("")) {
			if(!isList) {
				words = contentString.split("\\s+");
				if(words.length != 1)
					throw new FileContentsException(lineTooLongMsg + prefix);
			}
			else {
				words = contentString.split(",\\s*");
			}
		}
		else {
			if(!isList) 
				throw new FileContentsException(lineTooShortMsg + prefix);
			
			words = new String[0];
		}
		return words;
	}
	
	//Carga la partida.
	public void load(BufferedReader br) throws CommandExecuteException {
		int cycleCopy, sunCoinsCopy, remZombiesCopy;
		Level levelCopy = null;
		GameObjectList plantListCopy, zombieListCopy;
		String[]a;
		
		try {
			a= loadLine(br, "cycle", false);
			cycleCopy = Integer.parseInt(a[0]);
			
			a = loadLine(br, "sunCoins", false);
			sunCoinsCopy = Integer.parseInt(a[0]);
			
			a = loadLine(br, "level", false);
			
			levelCopy = Level.parse(a[0].toLowerCase());
			
			a = loadLine(br, "remZombies", false);
			remZombiesCopy = Integer.parseInt(a[0]);
			
			String[] pList = loadLine(br, "plantList", true);
			plantListCopy =  new GameObjectList(NUMPLANTS, pList, this);
			String[] zList = loadLine(br, "zombieList", true);
			zombieListCopy = new GameObjectList(levelCopy.getNumberOfZombies(), zList, this);
			
			this.turnCount = cycleCopy;
			this.sManager.setSuns(sunCoinsCopy);
			this.level = levelCopy;
			this.zManager.setZombies(remZombiesCopy);
			this.plantList = plantListCopy;
			this.zombieList = zombieListCopy;
			this.printer = new ReleasePrinter(FILAS, COLUMNAS);
			
		} catch (NumberFormatException | IOException | FileContentsException ex) {
			throw new CommandExecuteException(ex.getMessage());
		}
	}
	
	private void setObject(GameObject object, int x, int y) {
		object.setX(x);
		object.setY(y);
		object.setGame(this);
	}
}
