package tp.p3.logic;

import java.util.Scanner;

import tp.p3.Exceptions.CommandExecuteException;
import tp.p3.Exceptions.CommandParseException;
import tp.p3.commands.Command;
import tp.p3.commands.CommandParser;

//Controla la ejecuci�n del juego
public class Controller {
	
	//Atributos
	private Game game;
	private Scanner in;
	
	//Constructor
	public Controller(Game game) {
		this.game = game;
		in = new Scanner(System.in);
	}
	
	//Bucle principal del juego. Pide �rdenes y las ejecuta.
	public void run() {
		System.out.println("******Welcome to Plants vs Zombies v3.0******\n");
		printGame();

		while(!game.isFinished()) {
		
		 	System.out.print("Command > ");
		 	String[] words = in.nextLine().trim().split("\\s+");
		 	String h = "hOlA";
		 	h = h.toLowerCase();
		 	System.out.println(h);
		 	h = h.toUpperCase();
		 	System.out.println(h);
		 	try {
		 		Command command = CommandParser.parseCommand(words);
	 			if(command != null) {
	 				if(command.execute(game)) {
	 					game.update();		
	 					game.computerAction();	
	 					game.nextTurn();	
	 					printGame();
	 				}
	 			}
		 	}
		 	catch (CommandParseException | CommandExecuteException ex) {
		 		System.out.format( ex.getMessage() + "%n%n");
		 	}
		}
	}
		
	private void printGame() {
		System.out.println(game.draw());	
	}
}
