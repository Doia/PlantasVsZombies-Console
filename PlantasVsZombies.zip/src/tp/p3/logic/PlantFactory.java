package tp.p3.logic;

import tp.p3.Exceptions.PlantNameException;
import tp.p3.logic.objects.CherryBomb;
import tp.p3.logic.objects.Peashooter;
import tp.p3.logic.objects.Plants;
import tp.p3.logic.objects.Sunflower;
import tp.p3.logic.objects.Wallnut;

//Factor�a para las plantas.
public class PlantFactory {
	
	//Atributos
	private static Plants[] availablePlants = {
		new Sunflower(),
		new Peashooter(),
		new CherryBomb(),
		new Wallnut(),
	};
	
	//Crea y devuelve una planta seg�n su nombre.
	public static Plants getPlant (String name) throws PlantNameException {
	  	Plants p = null;
	  	for(Plants plant : availablePlants) {
	 		p = (Plants) plant.parse(name);
	 		if(p != null) 
	 			break;
	 	}
	  	if(p == null) {
	  		throw new PlantNameException("Unknown plant name: " + name);
	  	}
	  	return p;
	}
	 
	public static String listOfAvilablePlants() {
		StringBuilder cInfo = new StringBuilder();
		
		for (int i = 0; i < availablePlants.length; i++) {
			cInfo.append(availablePlants[i].plantText()).append("\n");
		}
		return cInfo.toString();
	}
}
