package tp.p3.logic;

import java.util.Random;

//Controla si debe de salir un zombie y la cuenta de los que quedan por salir.
public class ZombieManager {
	
	//Atributos
	private int zombies;
	
	//Constructor
	public ZombieManager(Level level) {
		this.zombies = level.getNumberOfZombies();
	}
	
	//Getters
	public int getZombies() {
		return this.zombies;
	}
	
	//Setters
	public void setZombies(int zombies) {
		this.zombies = zombies;
	}
	
	//Comprueba si el zombie puede salir o no.
	public  boolean comesOutZombie(Level level, Random rand) {
		double n = rand.nextDouble();
		boolean comesOut;
		
		if (n < level.getZombieFrequency()) {
			comesOut = true;
		}
		else {
			comesOut =  false;
		}
		return comesOut;
	}
	
	//Elige un tipo de zombie aleatorio.
	public String chooseType(Random rand) {
		int n = rand.nextInt(ZombieFactory.getNumberOfZombies());
		return ZombieFactory.getNameOfZombie(n);
	}

}
