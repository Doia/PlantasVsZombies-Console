package tp.p3.logic;

import tp.p3.Exceptions.FileContentsException;
import tp.p3.Exceptions.PlantNameException;
import tp.p3.logic.objects.GameObject;


//Clase con la lista de objetos.
public class GameObjectList {

	//Atributos
	private GameObject arrayObjects[]; 
	private int cont;
	
	//Contructor
	public GameObjectList(int MAX){
		 arrayObjects = new GameObject[MAX];
		 this.cont = 0;
	}
	
	public GameObjectList(int MAX, String[] list, Game game) throws FileContentsException {
		arrayObjects = new GameObject[MAX];

			this.cont = list.length;
			String[] object;
			for(int i = 0; i < this.cont; ++i) {
				object = list[i].split("\\:");
				if (object.length != 5) {
					throw new FileContentsException ("Fail to load game. Load failed: invalid file contents.");
				}
				load(object, i, game);
			}
		}
		
	//Getters
	public int getCont() {
		return this.cont;
	}
	
	//Setters
	public void setCont(int n) {
		this.cont = n;
	}
	
	//Realiza la acci�n de los objetos
	public void update() {
		for (int i = 0; i < this.cont; i++) {
			 this.arrayObjects[i].update();
		}
	}
	
	//Elimina un objeto de la lista.
	private void remove(int x) {
		for(int i = x; i < this.cont - 1; i++) {
			this.arrayObjects[i] = this.arrayObjects[i+1];
		}
		this.cont--;
	}
	
	//Comprueba si una posici�n est� vac�a.
	public boolean estaVacio(int x, int y) {
		boolean vacio=  true;

		int i = 0;
		while ((i < this.cont) && ( vacio) ) {
			if ( (this.arrayObjects[i].getX()  == x ) && ( this.arrayObjects[i].getY() == y ) ) {
				vacio = false;
			}
			i++;
		}
		return vacio;
	}
	
	//Devuelve el String de un objeto en una posici�n dada en modo Release.
	public String searchObjectRelease(int x, int y) {
		boolean encontrado = false;
		String ret = null;
		
		int i  = 0; 
		while((i< this.cont) && !encontrado) {
			if((this.arrayObjects[i].getX()  == x ) && ( this.arrayObjects[i].getY() == y )) {
				encontrado = true;
				ret = arrayObjects[i].toStringRelease();
			}
			i++;
		}
		return ret;
	}
	
	//Devuelve el String de un objeto en una posici�n dada en modo Debug.
	public String searchObjectDebug(int i) {
		String str;
		str = arrayObjects[i].toStringDebug();
		return str;
	}
	
	//Si el Objeto se ha quedado sin vida, lo elimina
	public void killObject() {
		for (int i = 0; i < this.cont;i++) {
			if (!this.arrayObjects[i].isAlive()) {
				remove(i);
				--i;
			}
		}
	}
	
	//A�ade un Objeto a la lista.
	public void addObject(GameObject object) {
		arrayObjects[this.cont]= object;
		this.cont++;
	}
	

	//Le quita vida a un objeto.
	public boolean takeDamageObject(int x, int y, int harm) {
		boolean encontrado = false;
		
		int i = 0; 
		while (i < this.cont && !encontrado) {
			if ( (this.arrayObjects[i].getX() == x) && (this.arrayObjects[i].getY() == y)) {
				encontrado = true;
				this.arrayObjects[i].losesLife(harm);
			}
			++i;
		}
		return encontrado;
	}
	
	public String save() {
		String cad = "";
		for(int i = 0; i < this.cont; ++i) {
			cad += this.arrayObjects[i].toStringSave() + ", ";
		}
		return cad ;
	}
	
	//Para cargar un partida.
	public void load(String[] object, int i, Game game) throws FileContentsException {
		
		try {
			GameObject o;
			o = ZombieFactory.getZombie(object[0].toLowerCase());
			if(o == null)
				o = PlantFactory.getPlant(object[0].toLowerCase());
					
			
			o.setGame(game);
			o.setLife(Integer.parseInt(object[1]));
			o.setX(Integer.parseInt(object[2]));
			o.setY(Integer.parseInt(object[3]));
			o.setFreqCount(Integer.parseInt(object[4]));
			
			this.arrayObjects[i] = o; 
		}
		catch (NumberFormatException | PlantNameException ex) {
			throw new FileContentsException ("Fail to load game. Load failed: invalid file contents.");
		}
	}
}
