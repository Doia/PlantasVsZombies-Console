package tp.p3.logic;

import tp.p3.logic.objects.BucketHead;
import tp.p3.logic.objects.NormalZombie;
import tp.p3.logic.objects.ZombieRunner;
import tp.p3.logic.objects.Zombies;

public class ZombieFactory {
	//Atributos
	private static Zombies[] availableZombies = {
		new BucketHead(),
		new NormalZombie(),
		new ZombieRunner(),	
	};
	
	//Crea y devuelve una planta seg�n su nombre.
	public static Zombies getZombie(String name) {
	  	Zombies z = null;
	  	for(Zombies zombie : availableZombies) {
	 		z = (Zombies) zombie.parse(name);
	 		if(z != null) 
	 			break;
	 	}
	  	return z;
	}
	
	public static String listOfAvilableZombies() {
		StringBuilder cInfo = new StringBuilder();
		
		for (int i = 0; i < availableZombies.length; i++) {
			cInfo.append(availableZombies[i].zombieText()).append("\n");
		}
		return cInfo.toString();
	}
	
	public static int getNumberOfZombies() {
		return availableZombies.length;
	}
	
	public static String getNameOfZombie(int n) {
		return availableZombies[n].getName();
	}	
}
