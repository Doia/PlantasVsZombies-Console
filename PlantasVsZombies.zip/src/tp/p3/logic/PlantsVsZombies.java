package tp.p3.logic;

import java.util.Random;

import tp.p3.Exceptions.ArgsNumberException;
import tp.p3.Exceptions.LevelException;
import tp.p3.Exceptions.seedException;

//Clase main
public class PlantsVsZombies {

	public static final String ArgsMsg = "Usage: plantsVsZombies " + "<" + Level.all("|") + "> [seed]";
	
	//Lee los par�metros(nivel y semilla) y crea los objetos necesarios para ejecutar el juego.
	public static void main(String[] args)  {
		Level level = null;
		long seed = 0;
		Game game;
		Controller control;
		try {
			if( (args.length < 1 ) || (args.length > 2)) {
				throw new ArgsNumberException(ArgsMsg);
			}
			else {
				level = Level.parse(args[0].toLowerCase());
				if(level == null) {
					throw new LevelException(ArgsMsg + ": level must be one of: " + Level.all(", ") );
				}
				
				if(args.length == 2) {
					try {
						seed = Long.parseLong(args[1]); 
					}
					catch (NumberFormatException a)  {
						throw new seedException(ArgsMsg + ": the seed must be a number");
					}
				}
				else {
					seed = new Random().nextInt(1000);
				}
				
				game = new Game(level, seed);
				control = new Controller(game);
				
				control.run();
			}
		} catch (ArgsNumberException | LevelException | seedException ex) {
			System.out.format( ex.getMessage() + "%n%n");
		}
	}
}
